package com.zolo.payingguests;

import java.util.HashMap;

import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.asserts.SoftAssert;

import com.zolo.utils.UIUtility;

public class RequestBed {
public static WebDriver driver1;
    
    @FindBy(how=How.XPATH, using="//div/a[@class='btn btn-blue btn-block']")
    WebElement requestingABedButton;
    
    @FindBy(how=How.XPATH, using="//h4[contains(text(),'Showing')]")
    WebElement requestBedPageTitle;
    
    @FindBy(how=How.XPATH, using="//div[@class='input-group']/input")
    WebElement dateFieldInRequestBedForm;
    
    @FindBy(how=How.XPATH, using="(//div[@class='offer-content']/descendant::h4)[3]")
    WebElement pgOfferContent;
    
    @FindBy(how=How.XPATH, using="(//button[contains(text(),'Proceed to Pay')])[1]")
    WebElement proceedToPayButton;
    
    @FindBy(how=How.XPATH, using="//div/h2")
    WebElement titleOfPaymentPage;
    
    @FindBy(how=How.XPATH, using="(//div[@class='col-md-4 form-group']/descendant::input)[1]")
    WebElement testUserField;
    
    @FindBy(how=How.XPATH, using="//div[contains(text(),'Make Payment')]")
    WebElement makePaymentButton;
    
    @FindBy(how=How.XPATH, using="(//div[@class='col-md-4 form-group']/descendant::input)[2]")
    WebElement emailField;
    
    @FindBy(how=How.XPATH, using="(//div[@class='col-md-4 form-group']/descendant::input)[3]")
    WebElement phoneField;
    
    @FindBy(how=How.XPATH, using="//div[contains(text(),'Make Payment')]")
    WebElement paymentSuccessfullMessage;
    
    @FindBy(how=How.XPATH, using="(//li[@class='list-group-item btn btn-default paytm ng-scope']/descendant::img[@alt='Pay via PayTM'])[2]")
    WebElement selectPaymentMethod;
    
    public UIUtility utility=new UIUtility();
    
    public RequestBed(WebDriver driver) {
        this.driver1 = driver;
        PageFactory.initElements(driver1, this);
        PropertyConfigurator.configure("log4j.properties");
    }
    
    /*****
     *  #Function Name :requestForBed
     *   #Description : Opens the search result, clicks on "Request for bed" button, search PG according to date and clicks button
     * */
        public  void requestForBed(HashMap<String, Object> data,SoftAssert softassert) {
        WebDriverWait wait = new WebDriverWait(driver1, 40);
        wait.until(ExpectedConditions.visibilityOf(requestingABedButton));
        utility.clickOnButton(requestingABedButton, "Requesting a bed");
        utility.elementIsDisplayed(requestBedPageTitle, "Request bed page title");
        wait.until(ExpectedConditions.visibilityOf(dateFieldInRequestBedForm));
        utility.input(dateFieldInRequestBedForm, data.get("BedRequiredDate").toString(), "Date field to filter");
        utility.keyTab(dateFieldInRequestBedForm);   
        wait.until(ExpectedConditions.visibilityOf(pgOfferContent));
        utility.clickOnLink(pgOfferContent);
        wait.until(ExpectedConditions.visibilityOf(proceedToPayButton));
        utility.clickOnButton(proceedToPayButton, "Proceed to pay");
        wait.until(ExpectedConditions.visibilityOf(titleOfPaymentPage));
        softassert.assertTrue(utility.elementIsDisplayed(titleOfPaymentPage, "Zolo Green gardern for Men"),"Element is not visible");        
    }
    
        /*****
         *  #Function Name :makePayment
         *   #Description : Verify the credential before making payment. And Selects the payment options
         * */
       public void makePayment(HashMap<String, Object> data,SoftAssert sa) {
        WebDriverWait wait = new WebDriverWait(driver1, 40);
        wait.until(ExpectedConditions.visibilityOf(testUserField));
        sa.assertEquals(testUserField.getText(), data.get("CurrentUserNameForPayment").toString());
        sa.assertEquals(emailField.getText(), data.get("EmailID").toString());
        sa.assertEquals(phoneField.getText(), data.get("PhonoNumber").toString());
        utility.clickOnButton(makePaymentButton, "Make payment");
        driver1.switchTo().defaultContent();
        utility.clickOnLink(selectPaymentMethod);
        wait.until(ExpectedConditions.visibilityOf(paymentSuccessfullMessage));
        sa.assertEquals(paymentSuccessfullMessage.getText(), "Total payment to be made to zolostays");
        }
}

package com.zolo.payingguests;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.util.HashMap;

import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.zolo.utils.UIUtility;

public class ScheduleVisitPage {
    public static WebDriver driver1;
    
    @FindBy(how=How.XPATH, using="//div/a[@class='btn btn-default btn-block']")
    WebElement scheduleAVisitButton;
    
    @FindBy(how=How.CSS, using=".ng-pristine.ng-valid.ng-not-empty.ng-valid-required.ng-touched")
    WebElement dateOfVisitField;
    
    @FindBy(how=How.CSS, using=".reason-drpdwn.form-control.ng-pristine.ng-empty.ng-invalid.ng-invalid-required.ng-touched")
    WebElement timeOfVisit;
    
    @FindBy(how=How.CSS, using=".btn.btn-lg.btn-blue")
    WebElement scheduleVisitButtonInSubmitForm;
    
//    @FindBy(how=How.XPATH, using="//p[@class='md-24 semi-bold']")
//    WebElement someDummyElement;
    
  
    
    public UIUtility utility=new UIUtility();
    
    public ScheduleVisitPage(WebDriver driver) {
        this.driver1 = driver;
        PageFactory.initElements(driver1, this);
        PropertyConfigurator.configure("log4j.properties");
    }   
    
    /*****
     *  #Function Name :scheduleVisitForPG:
     *   #Description : Opens a PG in the search result, scheduling the time for the visit
     * */
    public void scheduleVisitForPG(HashMap<String, Object> data,SoftAssert softassert) {
    try {
        WebDriverWait wait = new WebDriverWait(driver1, 30);
        wait.until(ExpectedConditions.visibilityOf(scheduleAVisitButton));
        utility.clickOnButton(scheduleAVisitButton, " Schedule a visit");
        Thread.sleep(3000);
/*        Robot bot = new Robot();
        bot.mouseMove(555, 425);    
        bot.mousePress(InputEvent.BUTTON1_MASK);
        bot.mouseRelease(InputEvent.BUTTON1_MASK);*/
        wait.until(ExpectedConditions.elementToBeClickable(scheduleAVisitButton)).clear();
        utility.input(dateOfVisitField, data.get("DateOfVisite").toString(), "Date of visit");
        wait.until(ExpectedConditions.elementToBeClickable(timeOfVisit)).clear();
        utility.selectByIndex(timeOfVisit, "2");
        utility.clickOnButton(scheduleVisitButtonInSubmitForm, "Schedule a visit");
    } catch (Exception e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }  
    }

}

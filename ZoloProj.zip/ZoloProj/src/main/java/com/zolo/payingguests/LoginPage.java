package com.zolo.payingguests;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.zolo.utils.UIUtility;

public class LoginPage{
    
    public static WebDriver driver1;
    
    @FindBy(how=How.XPATH, using="//a[contains(text(),'LOGIN')]")
    WebElement LoginButton;   
    
    @FindBy(how=How.XPATH, using="(//input[@name='name'])[1]")
    WebElement phoneNumberField;
    
    @FindBy(how=How.XPATH, using="(//input[@name='password'])[1]")
    WebElement passwordField;
    
    @FindBy(how=How.XPATH, using="//div/input[@value='Sign In']")
    WebElement SignInButton;
    
    @FindBy(how=How.XPATH, using="//input[@id='searchBar']")
    WebElement SearchBar;
    
    @FindBy(how=How.XPATH, using="//ul[@id='ui-id-1']/li[3]/div")
    WebElement SelectingFromTheList;
    
    @FindBy(how=How.XPATH, using="(//select)[1]")
    WebElement budgetDropdown;
    
    @FindBy(how=How.XPATH, using="(//select)[2]")
    WebElement sharingPreferenceDropdown;
    
    @FindBy(how=How.XPATH, using="(//select)[3]")
    WebElement PGTypeDropdown;
    
    @FindBy(how=How.XPATH, using="//a[@class='btn btn-primary handleFilter']/i")
    WebElement filterButtonicon;
    
    @FindBy(how=How.XPATH, using="//button/span[2][Contains(text(),'Search')]")
    WebElement searchButtons;
    
    @FindBy(how=How.XPATH, using="//div[@class='banner-content']/h1")
    WebElement welcomePageElement;
    
    @FindBy(how=How.XPATH, using="//div[@class='figType ng-binding']")
    WebElement PGSearchResultElement;
    
    @FindBy(how=How.XPATH, using="(//div[@class='figType ng-binding'])[1]")
    WebElement firstPGToVisitBeVisited;
    
    @FindBy(how=How.XPATH, using="(//div[@class='figType ng-binding'])[1]")
    WebElement scheduleAVisitButton;
    
    public UIUtility utility=new UIUtility();
    public Logger APP_LOGS = Logger.getLogger("ZOLO-Logger");
    
    public LoginPage(WebDriver driver) {
        this.driver1 = driver;
        PageFactory.initElements(driver1, this);
        PropertyConfigurator.configure("log4j.properties");
    }
    
    /*****
     *  #Function Name :LogintoApp
     *   #Description : Logins to application using user name and password, once login successfully validates if welcome page displayed
     * */
    public void LogintoApp(WebDriver driver, String appURL,String username, String password, SoftAssert softassert) {        
        try {
            driver1=driver;
            WebDriverWait wait = new WebDriverWait(driver, 20);
            driver.get(appURL);
            APP_LOGS.info("Started the Zolo paying guest application. URL is: "+appURL);
            wait.until(ExpectedConditions.visibilityOf(LoginButton));
            utility.clickOnButton(LoginButton,"LOGIN");
            wait.until(ExpectedConditions.visibilityOf(phoneNumberField));
            utility.input(phoneNumberField, username,"Phone Number");
            wait.until(ExpectedConditions.visibilityOf(passwordField));
            utility.input(passwordField, password, "Password");
            wait.until(ExpectedConditions.visibilityOf(passwordField));
            utility.clickOnButton(SignInButton, "SIGN IN");
            wait.until(ExpectedConditions.visibilityOf(welcomePageElement));
            softassert.assertTrue(utility.elementIsDisplayed(welcomePageElement, "ZOLO Co-Living space"), "Assert failed. Element is not displayed");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /*****
     *  #Function Name :SearchUsingCriteria
     *   #Description : In the search bar, searches PG availabed in the particular area.
     * */
    public void SearchUsingCriteria(HashMap<String, Object> data) {
       WebDriverWait wait = new WebDriverWait(driver1, 20);  
        wait.until(ExpectedConditions.visibilityOf(SearchBar));
        utility.input(SearchBar, data.get("Place").toString(),"Search bar");
        //utility.clickOnButton(searchButtons,"Search");
        wait.until(ExpectedConditions.visibilityOf(SelectingFromTheList));
        utility.clickOnLink(SelectingFromTheList);
    }

    /*****
     *  #Function Name :VerifyingSearchResult
     *   #Description : Once the area is selected, filters the result using, budget, SharingType and PGType
     * */
    @SuppressWarnings("unchecked")
    public void VerifyingSearchResult(HashMap<String, Object> data, SoftAssert softassert) {
        try {
            driver1.switchTo().defaultContent();
            WebDriverWait wait = new WebDriverWait(driver1, 40);
            wait.until(ExpectedConditions.visibilityOf(budgetDropdown));
            utility.selectVisibleText(budgetDropdown, data.get("Budget").toString(),"BUDGET ");
            wait.until(ExpectedConditions.visibilityOf(budgetDropdown));
            utility.selectVisibleText(sharingPreferenceDropdown, data.get("SharingType").toString()  ,"Sharing preference ");
            utility.selectVisibleText(PGTypeDropdown, data.get("PGType").toString(),"PG Type");
            softassert.assertTrue(utility.elementIsDisplayed(PGSearchResultElement, "PG Search result"), "Assert failed. Element is not displayed");
            List<WebElement> webelements = driver1.findElements(By.xpath("//div[@class='figType ng-binding']"));
            APP_LOGS.info("Number of PG result found is "+webelements.size());
            
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    /*****
     *  #Function Name :clickOnSearchResult
     *   #Description : clicks the result after filter applied, opens offer
     * */
    public void clickOnSearchResult(SoftAssert softassert) {
        WebDriverWait wait = new WebDriverWait(driver1, 40);
        wait.until(ExpectedConditions.visibilityOf(firstPGToVisitBeVisited));
        utility.clickOnLink(firstPGToVisitBeVisited);
        //driver1.switchTo().defaultContent();

    }
}

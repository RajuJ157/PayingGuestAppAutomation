package com.zolo.utils;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.ArrayList;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class UIUtility {
    String fileName;
    Workbook wb;
    Sheet ws;
    String Textformat;
    public Logger APP_LOGS = Logger.getLogger("ZOLO-Logger");
    
    /*****
     *  #Function Name :ReadFromExcelSheet
     *   #Description : To read the test data from the Excel sheet store it in the collection object
     * */
    public void ReadFromExcelSheet(String fileName, String sheetName)  {
        try {
            if (fileName.indexOf(".xlsx") > 0||fileName.indexOf(".xls") > 0) {
                wb = WorkbookFactory.create(new FileInputStream(fileName));
                ws = wb.getSheet(sheetName);
                this.fileName=fileName;
            } else {
                Assert.fail("provided file is not excel");
            }
        } catch (IOException io) {
            Assert.fail("File not found");
        }
        catch (InvalidFormatException io) {
            Assert.fail("Provided excel format is not valid");
        }
    }    

    /*****
     *  #Function Name :clickOnButton
     *   #Description : Clicks the the button element passed as argument
     * */
    public void clickOnButton(WebElement btn, String buttonType) {
        try {
            Thread.sleep(3000);
            btn.click();
            APP_LOGS.info("Clicked on \""+buttonType+"\" button.");
        } 
         catch (Exception e) {
             APP_LOGS.info("element not found"+e);
        }
    }
    /*****
     *  #Function Name :input
     *   #Description : Provide valus to the text box element
     * */    
    public void input(WebElement inputBox,String value, String fieldName) {
        try {
            inputBox.clear();
            inputBox.sendKeys(value);
            APP_LOGS.info("Value \""+value+"\" is passed to "+fieldName+".");
        } 
            
         catch (Exception e) {
           System.out.println(inputBox.getAttribute("id") + "  element not found");
        }
    }
    /*****
     *  #Function Name :selectVisibleText
     *   #Description : selects the value from the the dropdown using the options text value
     * */    
    public void selectVisibleText(WebElement visibleText, String text, String aboutDropdown) {
        try {
            Select select =new Select(visibleText);
            select.selectByVisibleText(text);
            APP_LOGS.info(" Value '"+  text+ "' selected from " +aboutDropdown+" dropdown");
        } catch (NoSuchElementException e) {
            APP_LOGS.info(visibleText.getText() + "is not found");
        } catch (Exception e) {
            APP_LOGS.info(visibleText.getText() + "is not found");
        }
    }
    /*****
     *  #Function Name :clickOnLink
     *   #Description : Clicks on the link element in the page
     * */        
    public void clickOnLink(WebElement linktext) {
        try {
            String strLinkText=linktext.getText();
            linktext.click();
            APP_LOGS.info("Clicked on Link \"" + strLinkText+"\".");
        } catch (NoSuchElementException e) {
            APP_LOGS.info(linktext.getAttribute("name") + "  element not found");
        } catch (Exception e) {
            APP_LOGS.info("element not found"+e);
        }
    }
    /*****
     *  #Function Name :elementIsDisplayed
     *   #Description : Checks the element is displayed in the page or not
     * */            
    public boolean elementIsDisplayed(WebElement element,String strAboutElement) {
        try {
            if ((element.isDisplayed())) {
                APP_LOGS.info("\""+element.getText() + "\" Element is displayed ");
                return true;
            }
        } catch (Exception e) {
            //APP_LOGS.info(e);
        }
        return false;
    }
    
    /*****
     *  #Function Name :selectByIndex
     *   #Description : Selects the value from the dropdown using index
     * */
    public void selectByIndex(WebElement selectByIndexValue, String strText) {
        try {
            int inttext = Integer.parseInt(strText);
            new Select(selectByIndexValue).selectByIndex(inttext);
            APP_LOGS.info(selectByIndexValue + strText
                    + " selected based on index");
        } 
        catch (Exception e) {
        APP_LOGS.info(selectByIndexValue + "is not found");
         Assert.fail("Element not found Exception");
        }
    }

    /*****
     *  #Function Name :keyTab
     *   #Description : Press tab on the input box
     * */
    public void keyTab(WebElement element) {
        try {
            element.sendKeys(Keys.TAB);
        } catch (NoSuchElementException e) {
            Assert.fail("Element not found");
        }
    }
    
    /**
     * @return list of key names as column as header in worksheet
     */
    public  List<Object> readAll()  {

        @SuppressWarnings("unchecked")
        HashMap<String, ArrayList<Object>> mapFile2 = read();
        List<Object> listele = new ArrayList<Object>();
        int rownum = getRowCount();
        for (int i = 0; i < rownum - 1; i++) {
            HashMap<String, Object> tempMap = new HashMap<String, Object>();

            for (Object key : mapFile2.keySet()) {
                List<Object> list = mapFile2.get(key);
                tempMap.put((String) key, list.get(i));
            }
            listele.add(tempMap);
        }
        return listele;
    }

    /*****
     *  #Function Name :read
     *   #Description : read the content from the excel sheet and assigned it collection object.
     * */
    @SuppressWarnings("rawtypes")
    public  HashMap read()  {
        LinkedHashMap<String, ArrayList<Object>> mapFile1 = new LinkedHashMap<String, ArrayList<Object>>();
        @SuppressWarnings("unused")
        int listSize = 0;   
        int j = 0;
        int noOfColumns = ws.getRow(0).getLastCellNum();
        int rowCount = ws.getLastRowNum() - ws.getFirstRowNum();
        for (int i = 0; i < noOfColumns; i++) {
            Row firstrow = ws.getRow(0);
            ArrayList<Object> ele = new ArrayList<Object>();
            for (j = 1; j <= rowCount; j++) {
                Row row1 = ws.getRow(j);
                Cell cell = null;
                Object value = null;
                cell = row1.getCell(i);
                DataFormatter dt=new DataFormatter();
                value=dt.formatCellValue(cell);
                ele.add(value);
            } 
            String mapValue = firstrow.getCell(i).getStringCellValue();
            mapFile1.put(mapValue, ele);// save each column data with first row
                                        // in column as key in hashmap
            listSize = ele.size();
        }
        return mapFile1;
    }

    /**
     * Get the used row count from sheet
     * @return row count
     */
    
    public int getRowCount(){
        
        int rowCount = ws.getPhysicalNumberOfRows();
        return rowCount;
    }
}


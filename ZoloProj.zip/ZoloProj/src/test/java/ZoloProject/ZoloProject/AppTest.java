package ZoloProject.ZoloProject;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.zolo.payingguests.LoginPage;
import com.zolo.payingguests.RequestBed;
import com.zolo.payingguests.ScheduleVisitPage;
import com.zolo.utils.UIUtility;

/**
 * Unit test for simple App.
 */
public class AppTest
{   
    public static List<Object> lstData;
    WebDriver driver;
    
    
    @Parameters({"testDataFileName","sheetName"})
    @BeforeSuite
    public void setupApplication(String testDataFileName,String sheetName) {
    System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+System.getProperty("file.separator")+"resources"+System.getProperty("file.separator")+"drivers"+System.getProperty("file.separator")+"geckodriver.exe");
    driver= new FirefoxDriver();
    UIUtility utility =new UIUtility();
    utility.ReadFromExcelSheet(System.getProperty("user.dir")+System.getProperty("file.separator")+"resources"+System.getProperty("file.separator")+"TestData"+System.getProperty("file.separator")+testDataFileName, sheetName);
    lstData=utility.readAll();
    }
    
    @Parameters({"appURL","UserName","Password"})
    @Test
    public void TC_01_LaunchApplicationAndLogin(String applicationURL,String userName,String password)
    { 
        SoftAssert softassert =new SoftAssert();
        LoginPage login=new LoginPage(driver);
        HashMap<String, Object> data = (HashMap<String, Object>) lstData.get(1);
        login.LogintoApp(driver,applicationURL,userName,password,softassert);
        login.SearchUsingCriteria(data);
        softassert.assertAll();
    }    
    
    @Test
    public void TC_02_VerifySearchResult()
    { 
        LoginPage login=new LoginPage(driver);
        HashMap<String, Object> data = (HashMap<String, Object>) lstData.get(2);
        SoftAssert softassert =new SoftAssert();
        login.VerifyingSearchResult(data, softassert);
        softassert.assertAll();
    }
    
    @Test
    public void TC_03_ScheduleVisitToPG()
    { 
        LoginPage login=new LoginPage(driver);
        ScheduleVisitPage scheduleVisit =new ScheduleVisitPage(driver);
        HashMap<String, Object> data = (HashMap<String, Object>) lstData.get(3);
        SoftAssert softassert =new SoftAssert();
        login.clickOnSearchResult(softassert);
        scheduleVisit.scheduleVisitForPG(data,softassert);
        softassert.assertAll();
    }
    
    @Test
    public void TC_04_RequestBed()
    { 
        LoginPage login=new LoginPage(driver);
        RequestBed requestBed=new RequestBed(driver);
        SoftAssert softassert =new SoftAssert();
        HashMap<String, Object> data = (HashMap<String, Object>) lstData.get(4);
        login.clickOnSearchResult(softassert);
        requestBed.requestForBed(data,softassert);
        softassert.assertAll();
    }
    
    @Test
    public void TC_05_MakePayment()
    { 
        LoginPage login=new LoginPage(driver);
        RequestBed requestBed=new RequestBed(driver);
        SoftAssert softassert =new SoftAssert();
        HashMap<String, Object> data = (HashMap<String, Object>) lstData.get(5);
        requestBed.makePayment(data,softassert);
        softassert.assertAll();
    }
    
    @AfterSuite
    public void quitBrowser() {
        driver.quit();

    }

}
